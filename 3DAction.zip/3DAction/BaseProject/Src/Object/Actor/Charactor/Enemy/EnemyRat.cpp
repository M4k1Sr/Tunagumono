#include <DxLib.h>
#include "../../../../Utility/AsoUtility.h"
#include "../../../../Manager/InputManager.h"
#include "../../../../Manager/SceneManager.h"
#include "../../../../Manager/ResourceManager.h"
#include "../../../../Manager/Resource.h"
#include "../../../../Object/Common/Transform.h"
#include "../../../Collider/ColliderLine.h"
#include "../../../Collider/ColliderCapsule.h"
#include "../../../../Object/Common/AnimationController.h"
#include "../../../../Application.h"
#include"./EnemyBase.h"
#include "EnemyRat.h"

EnemyRat::EnemyRat(const EnemyBase::EnemyData& data)
	:
	EnemyBase(data)

{
}

EnemyRat::~EnemyRat(void)
{
}

void EnemyRat::InitLoad(void)
{
	// ���N���X�̃��\�[�X���[�h
	EnemyBase::InitLoad();

	// ���f���ǂݍ���
	transform_.SetModel(
		resMng_.LoadModelDuplicate(ResourceManager::SRC::ENEMY_RAT));

}

void EnemyRat::InitTransform(void)
{

	// ���f���̑傫���A��]�A���W�̏�����
	transform_.scl = VGet(SCALE, SCALE, SCALE);
	transform_.quaRot = Quaternion::Identity();
	transform_.quaRotLocal = Quaternion::Euler(ROT);
	transform_.Update();
}

void EnemyRat::InitCollider(void)
{
	
	// ��ɒn�ʂƂ̏Փ˂Ŏg�p��������R���C�_
	ColliderLine* colLine = new ColliderLine(
		ColliderBase::TAG::ENEMY, &transform_,
		COL_LINE_START_LOCAL_POS, COL_LINE_END_LOCAL_POS);
	ownColliders_.emplace(static_cast<int>(COLLIDER_TYPE::LINE), colLine);

	// ��ɕǂ�؂Ȃǂ̏Փ˂Ŏd�l����J�v�Z���R���C�_
	ColliderCapsule* colCapsule = new ColliderCapsule(
		ColliderBase::TAG::ENEMY, &transform_,
		COL_CAPSULE_TOP_LOCAL_POS, COL_CAPSULE_DOWN_LOCAL_POS,
		COL_CAPSULE_RADIUS);
	ownColliders_.emplace(static_cast<int>(COLLIDER_TYPE::CAPSULE), colCapsule);

}

void EnemyRat::InitAnimation(void)
{

	//���f���A�j���[�V��������̏�����
	animationController_ = new AnimationController(transform_.modelId);

	animationController_->AddInFbx(
		static_cast<int>(ANIM_TYPE::IDLE),
		20.0f, 8);
	animationController_->AddInFbx(
		static_cast<int>(ANIM_TYPE::WALK),
		30.0f, 13);

	// �����A�j���[�V�����Đ�
	animationController_->Play(static_cast<int>(ANIM_TYPE::IDLE));

}

void EnemyRat::InitPost(void)
{

	// ��ԑJ�ڏ��������o�^
	stateChanges_.emplace(static_cast<int>(STATE::NONE),
		std::bind(&EnemyRat::ChangeStateNone, this));

	stateChanges_.emplace(static_cast<int>(STATE::THINK),
		std::bind(&EnemyRat::ChangeStateThink, this));

	stateChanges_.emplace(static_cast<int>(STATE::IDLE),
		std::bind(&EnemyRat::ChangeStateIdle, this));

	stateChanges_.emplace(static_cast<int>(STATE::WANDER),
		std::bind(&EnemyRat::ChangeStateWander, this));

	stateChanges_.emplace(static_cast<int>(STATE::END),
		std::bind(&EnemyRat::ChangeStateEnd, this));

	// ������Ԑݒ�
	ChangeState(STATE::THINK);
}

void EnemyRat::UpdateProcess(void)
{

	// ��ԕʍX�V
	stateUpdate_();


	//switch (state_)
	//{
	//case EnemyRat::STATE::NONE:
	//	UpdateNone();
	//	break;
	//case EnemyRat::STATE::THINK:
	//	UpdateThink();
	//	break;
	//case EnemyRat::STATE::IDLE:
	//	UpdateIdle();
	//	break;
	//case EnemyRat::STATE::WANDER:
	//	UpdateWander();
	//	break;
	//case EnemyRat::STATE::END:
	//	UpdateEnd();
	//	break;
	//}

}

void EnemyRat::UpdateProcessPost(void)
{

	EnemyBase::UpdateProcessPost();

	if (!InMovableRange())
	{
		transform_.pos = prevPos_;
		transform_.Update();

		// �v�l��Ԃɖ߂�
		ChangeState(STATE::THINK);
	}

	

}

void EnemyRat::ChangeState(STATE state)
{
	state_ = state;

	// �e��Ԃ̏�����Ԑݒ�
	EnemyBase::ChangeState(static_cast<int>(state_));


	//state_ = state;
	//switch (state)
	//{
	//case EnemyRat::STATE::NONE:
	//	ChangeStateNone();
	//	break;
	//case EnemyRat::STATE::THINK:
	//	ChangeStateThink();
	//	break;
	//case EnemyRat::STATE::IDLE:
	//	ChangeStateIdle();
	//	break;
	//case EnemyRat::STATE::WANDER:
	//	ChangeStateWander();
	//	break;
	//case EnemyRat::STATE::END:
	//	ChangeStateEnd();
	//	break;
	//}

}

void EnemyRat::ChangeStateNone(void)
{
	stateUpdate_ = std::bind(&EnemyRat::UpdateNone, this);
}

void EnemyRat::ChangeStateThink(void)
{
	stateUpdate_ = std::bind(&EnemyRat::UpdateThink, this);

	// �v�l
	// �����_���Ɏ��̍s��������
	// 30%�őҋ@�A70%�Ŝp�j
	int rand = GetRand(100);

	if (rand < 30)
	{
		ChangeState(STATE::IDLE);
	}
	else
	{
		ChangeState(STATE::WANDER);
	}
}

void EnemyRat::ChangeStateIdle(void)
{
	stateUpdate_ = std::bind(&EnemyRat::UpdateIdle, this);

	// �����_���ȑҋ@����
	step_ = 3.0f + static_cast<float>(GetRand(3));

	// �ړ��ʃ[��
	movePow_ = AsoUtility::VECTOR_ZERO;

	// �ҋ@�A�j���[�V�����Đ�
	animationController_->Play(
		static_cast<int>(ANIM_TYPE::IDLE), true);

}

void EnemyRat::ChangeStateWander(void)
{
	stateUpdate_ = std::bind(&EnemyRat::UpdateWander, this);

	// �����_���Ȋp�x
	float angle = static_cast<float>(GetRand(360)) * DX_PI_F / 180.0f;

	// �ړ�����
	moveDir_ = VGet(cosf(angle), 0.0f, sinf(angle));

	// �����_���Ȉړ�����
	step_ = 2.0f + static_cast<float>(GetRand(5));

	// �ړ��X�s�[�h
	moveSpeed_ = 3.0f;

	// �����A�j���[�V�����Đ�
	animationController_->Play(
		static_cast<int>(ANIM_TYPE::WALK), true);

}

void EnemyRat::ChangeStateEnd(void)
{
	stateUpdate_ = std::bind(&EnemyRat::UpdateEnd, this);
}

void EnemyRat::UpdateNone(void)
{
}

void EnemyRat::UpdateThink(void)
{
}

void EnemyRat::UpdateIdle(void)
{

	step_ -= SceneManager::GetInstance().GetDeltaTime(); // �܂��� -= 1.0f;

	if (step_ <= 0.0f)
	{
		ChangeState(STATE::THINK);
	}
}

void EnemyRat::UpdateWander(void)
{
	// ���t���[���ړ�
	movePow_ = VScale(moveDir_, moveSpeed_);
	transform_.pos = VAdd(transform_.pos, movePow_);

	// ���Ԍo�߃`�F�b�N
	step_ -= SceneManager::GetInstance().GetDeltaTime(); // �܂��� -= 1.0f;
	if (step_ <= 0.0f)
	{
		ChangeState(STATE::THINK);
	}
}

void EnemyRat::UpdateEnd(void)
{
}
