#include "../../../../Utility/AsoUtility.h"
#include "../../../../Manager/ResourceManager.h"
#include "../../../../Manager/SceneManager.h"
#include "../../../Common/AnimationController.h"
#include "../../../Collider/ColliderLine.h"
#include "../../../Collider/ColliderCapsule.h"
#include "EnemyRobot.h"

EnemyRobot::EnemyRobot(const EnemyBase::EnemyData& data)
	:
	EnemyBase(data),
	state_(STATE::NONE),
	step_(0.0f)
{
}

EnemyRobot::~EnemyRobot(void)
{
}

void EnemyRobot::Draw(void)
{

	// ���N���X�̕`�揈��
	CharactorBase::Draw();

#ifdef _DEBUG

	// ���񃋁[�g�`��
	for (const auto& point : wayPoints_)
	{

		DrawSphere3D(
			point, 50.0f, 10,
			0x0000ff, 0x0000ff, false);

	}

#endif // _DEBUG

}

void EnemyRobot::InitLoad(void)
{
	// ���N���X�̃��\�[�X���[�h
	CharactorBase::InitLoad();

	// ���f���̃��[�h
	transform_.SetModel(
		resMng_.LoadModelDuplicate(ResourceManager::SRC::ENEMY_ROBOT));
}

void EnemyRobot::InitTransform(void)
{
	transform_.scl = VScale(AsoUtility::VECTOR_ONE, SCALE);

	transform_.quaRot = Quaternion();

	transform_.quaRotLocal = Quaternion::Euler(DEFAULT_LOCAL_ROT);

	transform_.Update();
}

void EnemyRobot::InitCollider(void)
{
	// ��ɒn�ʂƂ̏Փ˂Ŏd�l��������R���C�_
	ColliderLine* colLine = new ColliderLine(
		ColliderBase::TAG::ENEMY, &transform_,
		COL_LINE_START_LOCAL_POS, COL_LINE_END_LOCAL_POS);

	ownColliders_.emplace(
		static_cast<int>(COLLIDER_TYPE::LINE), colLine);

	// ��ɕǂ�؂Ȃǂ̏Փ˂Ŏd�l����J�v�Z���R���C�_
	ColliderCapsule* colCapsule = new ColliderCapsule(
		ColliderBase::TAG::ENEMY, &transform_,
		COL_CAPSULE_TOP_LOCAL_POS,
		COL_CAPSULE_DOWN_LOCAL_POS, COL_CAPSULE_RADIUS);

	ownColliders_.emplace(
		static_cast<int>(COLLIDER_TYPE::CAPSULE), colCapsule);

}

void EnemyRobot::InitAnimation(void)
{
	animationController_ = new AnimationController(transform_.modelId);

	// FBX���̃A�j���[�V�����ݒ�
	int type = -1;

	type = static_cast<int>(ANIM_TYPE::DANCE);
	animationController_->AddInFbx(type, 10.0f, type);
	type = static_cast<int>(ANIM_TYPE::IDLE);
	animationController_->AddInFbx(type, 20.0f, type);
	type = static_cast<int>(ANIM_TYPE::WALK);
	animationController_->AddInFbx(type, 30.0f, type);
	type = static_cast<int>(ANIM_TYPE::RUN);
	animationController_->AddInFbx(type, 30.0f, type);
	type = static_cast<int>(ANIM_TYPE::KICK);
	animationController_->AddInFbx(type, 45.0f, type);
	type = static_cast<int>(ANIM_TYPE::SHOOT);
	animationController_->AddInFbx(type, 30.0f, type);

	// �����A�j���[�V�����Đ�
	animationController_->Play(static_cast<int>(ANIM_TYPE::IDLE), true);

}

void EnemyRobot::InitPost(void)
{
	// ��ԑJ�ڏ��������o�^
	stateChanges_.emplace(static_cast<int>(STATE::NONE),
		std::bind(&EnemyRobot::ChangeStateNone, this));
	stateChanges_.emplace(static_cast<int>(STATE::THINK),
		std::bind(&EnemyRobot::ChangeStateThink, this));
	stateChanges_.emplace(static_cast<int>(STATE::IDLE),
		std::bind(&EnemyRobot::ChangeStateIdle, this));
	stateChanges_.emplace(static_cast<int>(STATE::PATROL),
		std::bind(&EnemyRobot::ChangeStatePatrol, this));
	stateChanges_.emplace(static_cast<int>(STATE::SURPRISE),
		std::bind(&EnemyRobot::ChangeStateSurprise, this));
	stateChanges_.emplace(static_cast<int>(STATE::ALERT),
		std::bind(&EnemyRobot::ChangeStateAlert, this));
	stateChanges_.emplace(static_cast<int>(STATE::CHASE),
		std::bind(&EnemyRobot::ChangeStateChase, this));
	stateChanges_.emplace(static_cast<int>(STATE::ATTACK_KICK),
		std::bind(&EnemyRobot::ChangeStateAttackKick, this));
	stateChanges_.emplace(static_cast<int>(STATE::ATTACK_SHOOT),
		std::bind(&EnemyRobot::ChangeStateAttackShoot, this));
	stateChanges_.emplace(static_cast<int>(STATE::ESCAPE),
		std::bind(&EnemyRobot::ChangeStateEscape, this));
	stateChanges_.emplace(static_cast<int>(STATE::DEAD),
		std::bind(&EnemyRobot::ChangeStateDead, this));
	stateChanges_.emplace(static_cast<int>(STATE::KNOCKBACK),
		std::bind(&EnemyRobot::ChangeStateKnockBack, this));
	stateChanges_.emplace(static_cast<int>(STATE::END),
		std::bind(&EnemyRobot::ChangeStateEnd, this));

	// ���񃋁[�g
	wayPoints_.emplace_back(VGet(1926.18f, 1.76f, 618.34f));
	wayPoints_.emplace_back(VGet(2553.30f, -11.82f, -593.32f));
	wayPoints_.emplace_back(VGet(1400.34f, -26.21f, -457.11f));
	wayPoints_.emplace_back(VGet(1274.85f, -49.35f, 168.02f));

	// ������Ԑݒ�
	ChangeState(STATE::THINK);
}

void EnemyRobot::UpdateProcess(void)
{
	// ��ԕʍX�V
	stateUpdate_();
}

void EnemyRobot::UpdateProcessPost(void)
{
	EnemyBase::UpdateProcessPost();
}

void EnemyRobot::ChangeState(STATE state)
{
	state_ = state;

	EnemyBase::ChangeState(static_cast<int>(state_));
}

void EnemyRobot::ChangeStateNone(void)
{
	stateUpdate_ = std::bind(&EnemyRobot::UpdateNone, this);
}

void EnemyRobot::ChangeStateThink(void)
{
	stateUpdate_ = std::bind(&EnemyRobot::UpdateThink, this);

	// �v�l
	// �����_���Ɏ��̍s��������
	// 30%�őҋ@�A70%�Ŝp�j
	int rand = GetRand(100);

	if (rand < 30)
	{
		ChangeState(STATE::IDLE);
	}
	else
	{
		ChangeState(STATE::PATROL);
	}

}

void EnemyRobot::ChangeStateIdle(void)
{
	stateUpdate_ = std::bind(&EnemyRobot::UpdateIdle, this);

	// �����_���ȑҋ@����
	step_ = 3.0f + static_cast<float>(GetRand(3));

	// �ړ��ʃ[��
	movePow_ = AsoUtility::VECTOR_ZERO;

	// �ҋ@�A�j���[�V�����Đ�
	animationController_->Play(
		static_cast<int>(ANIM_TYPE::IDLE), true);

}

void EnemyRobot::ChangeStatePatrol(void)
{
	stateUpdate_ = std::bind(&EnemyRobot::UpdatePatrol, this);

	// �ړ��ʃ[��
	movePow_ = AsoUtility::VECTOR_ZERO;

	if (activeWayPointIndex_ == wayPoints_.size())
	{
		// ����I��
		
		ChangeState(STATE::THINK);
		return;
	}

	// ���̏���|�C���g�X�V
	�Z�Z�Z

	// ���񃋁[�g�̈ړ�������ݒ肷��
	SetMoveDirPatrol();

	// �ړ��X�s�[�h
	moveSpeed_ = 5.0f;

	// �����A�j���[�V�����Đ�
	animationController_->Play(
		static_cast<int>(ANIM_TYPE::WALK), true);
}

void EnemyRobot::ChangeStateSurprise(void)
{
	stateUpdate_ = std::bind(&EnemyRobot::UpdateSurprise, this);
}

void EnemyRobot::ChangeStateAlert(void)
{
	stateUpdate_ = std::bind(&EnemyRobot::UpdateAlert, this);
}

void EnemyRobot::ChangeStateChase(void)
{
	stateUpdate_ = std::bind(&EnemyRobot::UpdateChase, this);
}

void EnemyRobot::ChangeStateAttackKick(void)
{
	stateUpdate_ = std::bind(&EnemyRobot::UpdateAttackKick, this);
}

void EnemyRobot::ChangeStateAttackShoot(void)
{
	stateUpdate_ = std::bind(&EnemyRobot::UpdateAttackShoot, this);
}

void EnemyRobot::ChangeStateEscape(void)
{
	stateUpdate_ = std::bind(&EnemyRobot::UpdateEscape, this);
}

void EnemyRobot::ChangeStateDead(void)
{
	stateUpdate_ = std::bind(&EnemyRobot::UpdateDead, this);
}

void EnemyRobot::ChangeStateKnockBack(void)
{
	stateUpdate_ = std::bind(&EnemyRobot::UpdateKnockBack, this);
}

void EnemyRobot::ChangeStateEnd(void)
{
	stateUpdate_ = std::bind(&EnemyRobot::UpdateEnd, this);
}

void EnemyRobot::UpdateNone(void)
{
}

void EnemyRobot::UpdateThink(void)
{
}

void EnemyRobot::UpdateIdle(void)
{
	step_ -= scnMng_.GetDeltaTime();

	if (step_ < 0.0f)
	{
		// �ҋ@�I��
		ChangeState(STATE::THINK);
		return;
	}
}

void EnemyRobot::UpdatePatrol(void)
{
	// ����|�C���g�Ƃ̋��̏Փ˔���(���a30.0f���炢)
	�Z�Z�Z
	{
		// ����|�C���g�C���f�b�N�X�X�V
		�Z�Z�Z
		// ���̈ړ��n�_�ւ��A�ҋ@���v�l
		ChangeState(STATE::THINK);
		return;
	}
	// ���񃋁[�g�̈ړ�������ݒ肷��
	SetMoveDirPatrol();
	// �ړ��ʂ̌v�Z
	�Z�Z�Z

}

void EnemyRobot::UpdateSurprise(void)
{
}

void EnemyRobot::UpdateAlert(void)
{
}

void EnemyRobot::UpdateChase(void)
{
}

void EnemyRobot::UpdateAttackKick(void)
{
}

void EnemyRobot::UpdateAttackShoot(void)
{
}

void EnemyRobot::UpdateEscape(void)
{
}

void EnemyRobot::UpdateDead(void)
{
}

void EnemyRobot::UpdateKnockBack(void)
{
}

void EnemyRobot::UpdateEnd(void)
{
}

void EnemyRobot::SetMoveDirPatrol(void)
{
	// �������WXZ
	VECTOR tmpPos = nextWayPoint_;
	tmpPos.y = 0.0f;

	// ���ݒn���WXZ
	VECTOR pos = transform_.pos;
	pos.y = 0.0f;

	// XZ���ʏ�̈ړ��������v�Z
	moveDir_ = VNorm(VSub(tmpPos, pos));

}

